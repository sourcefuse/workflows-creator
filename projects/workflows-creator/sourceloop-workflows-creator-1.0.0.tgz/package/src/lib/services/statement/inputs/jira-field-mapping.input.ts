import {ValueInput} from './value.input';

export class JiraFieldMappingInput extends ValueInput {
  prefix = 'and Map';
  placeholder ='these fields'
  suffix = 'for the item and jira issue';
  static identifier = 'JiraFieldMappingInput';
  isLink = true;

  getIdentifier(): string {
    return JiraFieldMappingInput.identifier;
  }
}
