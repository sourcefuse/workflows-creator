import {ValueInput} from './value.input';

export class JiraAccountConnectInput extends ValueInput {
  static identifier = 'JiraAccountConnectInput';
  prefix = 'Connect your';
  placeholder = 'Jira account';
  suffix = 'to';
  isLink = true;

  getIdentifier(): string {
    return JiraAccountConnectInput.identifier;
  }
}
