import {ValueInput} from './value.input';

export class JiraProjectSelectInput extends ValueInput {
  static identifier = 'JiraProjectSelectInput';
  prefix = 'Create an issue in';
  placeholder = 'this project';
  isLink = true;

  getIdentifier(): string {
    return JiraProjectSelectInput.identifier;
  }
}
